#ifndef UTILITIES_H
#define UTILITIES_H

void initHardware();
bool checkModeSwitch();
long getFilteredDistance();
void rotateScanner(int angle);
void lockTarget(int angle);
void enableLaser();
void disableLaser();
void sendToProcessing(int angle, long dist);
void logDetection(int angle, long dist);
int readJoystickAngle();

#endif