#ifndef RADAR_SCANNER_H
#define RADAR_SCANNER_H

void runRadarScanner();

#endif