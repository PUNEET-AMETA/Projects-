#include "ManualControl.h"
#include "Utilities.h"

void runManualControl() {
  int angle = readJoystickAngle();
  rotateScanner(angle);
  lockTarget(angle);

  long dist = getFilteredDistance();

  if (dist < 25 && dist > 2) {
    enableLaser();
  } else {
    disableLaser();
  }

  sendToProcessing(angle, dist);
}