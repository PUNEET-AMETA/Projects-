#include <Servo.h>
#include "Utilities.h"

const int trigPin = 14;
const int echoPin = 16;
const int laserControlPin = 7;
const int servoScannerPin = 9;
const int servoStopperPin = 10;
const int joystickX = A1;
const int joystickButton = 2;

Servo servoScanner;
Servo servoStopper;

void initHardware() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(laserControlPin, OUTPUT);
  pinMode(joystickButton, INPUT_PULLUP);
  servoScanner.attach(servoScannerPin);
  servoStopper.attach(servoStopperPin);
  digitalWrite(laserControlPin, LOW);
}

bool checkModeSwitch() {
  static bool lastState = HIGH;
  bool currentState = digitalRead(joystickButton);
  if (lastState == HIGH && currentState == LOW) {
    delay(300); // Debounce
    lastState = LOW;
    return true;
  }
  lastState = currentState;
  return false;
}

long getFilteredDistance() {
  long total = 0;
  const int samples = 5;
  for (int i = 0; i < samples; i++) {
    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigPin, LOW);
    long duration = pulseIn(echoPin, HIGH, 25000);
    total += duration * 0.034 / 2;
  }
  return total / samples;
}

void rotateScanner(int angle) {
  servoScanner.write(angle);
  delay(15);
}

void lockTarget(int angle) {
  servoStopper.write(angle);
}

void enableLaser() {
  digitalWrite(laserControlPin, HIGH);
}

void disableLaser() {
  digitalWrite(laserControlPin, LOW);
}

void sendToProcessing(int angle, long dist) {
  Serial.print(angle);
  Serial.print(",");
  Serial.println(dist);
}

void logDetection(int angle, long dist) {
  Serial.print("Target Detected @ ");
  Serial.print(angle);
  Serial.print("° , ");
  Serial.print(dist);
  Serial.println(" cm");
}

int readJoystickAngle() {
  int xVal = analogRead(joystickX);
  int angle = map(xVal, 0, 1023, 0, 180);
  return constrain(angle, 0, 180);
}