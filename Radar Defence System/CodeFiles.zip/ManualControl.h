#ifndef MANUAL_CONTROL_H
#define MANUAL_CONTROL_H

void runManualControl();

#endif