#include "RadarScanner.h"
#include "Utilities.h"

void runRadarScanner() {
  for (int angle = 0; angle <= 180; angle += 1) {
    scanAndAct(angle);
  }
  for (int angle = 180; angle >= 0; angle -= 1) {
    scanAndAct(angle);
  }
}

void scanAndAct(int angle) {
  rotateScanner(angle);
  long dist = getFilteredDistance();

  if (dist < 25 && dist > 2) {
    lockTarget(angle);
    enableLaser();
    logDetection(angle, dist);
  } else {
    disableLaser();
  }

  sendToProcessing(angle, dist);
}